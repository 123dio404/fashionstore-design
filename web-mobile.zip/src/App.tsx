import { useState, useCallback } from 'react';
import type { Tab, CartItem, Reservation, Product, AppPhase, OverlayScreen, Purchase } from './types';
import WebApp from './web/WebApp';
import { INITIAL_RESERVATIONS, INITIAL_PURCHASES } from './data';
import { BottomNav, OfflineBanner, C, T } from './ui';

// Screens — auth flow
import SplashScreen from './SplashScreen';
import OnboardingScreen from './OnboardingScreen';
import LoginScreen from './LoginScreen';
import RegisterScreen from './RegisterScreen';

// Screens — main tabs
import HomeScreen from './HomeScreen';
import CatalogScreen from './CatalogScreen';
import ReservationsScreen from './ReservationsScreen';
import CartScreen from './CartScreen';
import ProfileScreen from './ProfileScreen';

// Screens — overlays
import CheckoutScreen from './CheckoutScreen';
import PurchaseSuccessScreen from './PurchaseSuccessScreen';
import PurchasesScreen from './PurchasesScreen';
import ARFitterScreen from './ARFitterScreen';
import AIRecommendationsScreen from './AIRecommendationsScreen';
import ChatbotScreen from './ChatbotScreen';
import VoiceScreen from './VoiceScreen';
import PreferencesScreen from './PreferencesScreen';
import SupportScreen from './SupportScreen';
import SettingsScreen from './SettingsScreen';
import StateDemoScreen from './StateScreens';

// ─── Mobile App ─────────────────────────────────────────────────────
function MobileApp({ onSwitchToWeb }: { onSwitchToWeb: () => void }) {
  const W = 390, H = 844;

  const [phase, setPhase] = useState<AppPhase>('splash');
  const [tab, setTab] = useState<Tab>('home');
  const [overlay, setOverlay] = useState<OverlayScreen>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [favs, setFavs] = useState<number[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>(INITIAL_RESERVATIONS);
  const [purchases, setPurchases] = useState<Purchase[]>(INITIAL_PURCHASES);
  const [arProductId, setArProductId] = useState<number | undefined>(undefined);
  const [toast, setToast] = useState<string | null>(null);
  const [isOffline, setIsOffline] = useState(false);
  const [lastPurchase, setLastPurchase] = useState<Purchase | null>(null);

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);
  const reservCount = reservations.filter(r => r.status === 'confirmada').length;

  const addToCart = useCallback((p: Product) => {
    setCart(prev => {
      const existing = prev.find(i => i.productId === p.id);
      if (existing) return prev.map(i => i.productId === p.id ? { ...i, qty: i.qty + 1 } : i);
      return [...prev, {
        productId: p.id, name: p.name, brand: p.brand,
        price: p.price, image: p.image, size: p.sizes[0] ?? 'M',
        color: p.colors[0]?.name ?? '', qty: 1,
      }];
    });
    setToast(`${p.name} agregado al carrito`);
    setTimeout(() => setToast(null), 2000);
  }, []);

  const handleProductClick = useCallback((p: Product) => {
    setArProductId(p.id);
    setOverlay('ar-fitter');
  }, []);

  const handleCheckoutSuccess = useCallback((purchase: Purchase) => {
    setPurchases(prev => [purchase, ...prev]);
    setCart([]);
    setLastPurchase(purchase);
    setOverlay('purchase-success');
  }, []);

  const handleAddReservation = useCallback((r: Reservation) => {
    setReservations(prev => [r, ...prev]);
  }, []);

  const handleCancelReservation = useCallback((id: string) => {
    setReservations(prev => prev.map(r => r.id === id ? { ...r, status: 'cancelada' as const } : r));
  }, []);

  const renderScreen = () => {
    switch (tab) {
      case 'home':
        return (
          <HomeScreen
            isOffline={isOffline}
            favs={favs}
            onToggleFav={(id) => setFavs(prev => prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id])}
            onAddToCart={addToCart}
            onProductClick={handleProductClick}
            onGoToCatalog={() => setTab('catalog')}
            onOpenVoice={() => setOverlay('voice')}
            onOpenChatbot={() => setOverlay('chatbot')}
            toast={toast}
            onDismissToast={() => setToast(null)}
          />
        );
      case 'catalog':
        return (
          <CatalogScreen
            isOffline={isOffline}
            favs={favs}
            onToggleFav={(id) => setFavs(prev => prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id])}
            onAddToCart={addToCart}
            onProductClick={handleProductClick}
            onOpenVoice={() => setOverlay('voice')}
            onOpenChatbot={() => setOverlay('chatbot')}
            toast={toast}
            onDismissToast={() => setToast(null)}
          />
        );
      case 'reservations':
        return (
          <ReservationsScreen
            isOffline={isOffline}
            reservations={reservations}
            onAddReservation={handleAddReservation}
            onCancelReservation={handleCancelReservation}
          />
        );
      case 'cart':
        return (
          <CartScreen
            cart={cart}
            isOffline={isOffline}
            onQtyInc={(id, size) => setCart(prev => prev.map(i => i.productId === id && i.size === size ? { ...i, qty: i.qty + 1 } : i))}
            onQtyDec={(id, size) => setCart(prev => prev.map(i => i.productId === id && i.size === size ? { ...i, qty: Math.max(0, i.qty - 1) } : i).filter(i => i.qty > 0))}
            onRemove={(id, size) => setCart(prev => prev.filter(i => !(i.productId === id && i.size === size)))}
            onGoToCatalog={() => setTab('catalog')}
            onCheckout={() => setOverlay('checkout')}
          />
        );
      case 'profile':
        return (
          <ProfileScreen
            isOffline={isOffline}
            setIsOffline={setIsOffline}
            favsCount={favs.length}
            cartCount={cartCount}
            onOpenPurchases={() => setOverlay('purchases')}
            onOpenPreferences={() => setOverlay('preferences')}
            onOpenSettings={() => setOverlay('settings')}
            onOpenSupport={() => setOverlay('support')}
            onOpenAIRecs={() => setOverlay('ai-recs')}
            onOpenChatbot={() => setOverlay('chatbot')}
            onOpenVoice={() => setOverlay('voice')}
            onOpenStateDemo={() => setOverlay('state-demo')}
            onLogout={() => setPhase('login')}
          />
        );
    }
  };

  const renderOverlay = () => {
    switch (overlay) {
      case 'checkout':
        return <CheckoutScreen cart={cart} onBack={() => setOverlay(null)} onSuccess={handleCheckoutSuccess} />;
      case 'purchase-success':
        return lastPurchase ? (
          <PurchaseSuccessScreen
            purchase={lastPurchase}
            onViewPurchases={() => { setOverlay('purchases'); }}
            onContinueShopping={() => { setOverlay(null); setTab('home'); }}
          />
        ) : null;
      case 'purchases':
        return <PurchasesScreen purchases={purchases} onBack={() => setOverlay(null)} />;
      case 'ar-fitter':
        return <ARFitterScreen onBack={() => setOverlay(null)} initialProductId={arProductId} />;
      case 'ai-recs':
        return (
          <AIRecommendationsScreen
            onBack={() => setOverlay(null)}
            onProductClick={handleProductClick}
            onAddToCart={addToCart}
            favs={favs}
            onToggleFav={(id) => setFavs(prev => prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id])}
          />
        );
      case 'chatbot':
        return <ChatbotScreen onBack={() => setOverlay(null)} />;
      case 'voice':
        return <VoiceScreen onBack={() => setOverlay(null)} />;
      case 'preferences':
        return <PreferencesScreen onBack={() => setOverlay(null)} onSave={() => setOverlay(null)} />;
      case 'support':
        return <SupportScreen onBack={() => setOverlay(null)} />;
      case 'settings':
        return <SettingsScreen onBack={() => setOverlay(null)} onLogout={() => setPhase('login')} onSave={() => {}} />;
      case 'state-demo':
        return <StateDemoScreen onBack={() => setOverlay(null)} />;
      default:
        return null;
    }
  };

  if (phase === 'splash') return <Shell W={W} H={H}><SplashScreen onDone={() => setPhase('onboarding')} /></Shell>;
  if (phase === 'onboarding') return <Shell W={W} H={H}><OnboardingScreen onDone={() => setPhase('login')} /></Shell>;
  if (phase === 'login') return <Shell W={W} H={H}><LoginScreen onSuccess={() => setPhase('app')} onGoRegister={() => setPhase('register')} /></Shell>;
  if (phase === 'register') return <Shell W={W} H={H}><RegisterScreen onSuccess={() => setPhase('app')} onGoLogin={() => setPhase('login')} /></Shell>;

  return (
    <Shell W={W} H={H} onSwitchToWeb={onSwitchToWeb}>
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: C.bg, position: 'relative', overflow: 'hidden' }}>
        {isOffline && <OfflineBanner />}
        <div style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', display: 'flex', flexDirection: 'column' }} className="no-scrollbar">
          {renderScreen()}
        </div>
        <BottomNav active={tab} onTab={(t) => setTab(t)} cartCount={cartCount} reservCount={reservCount} />
        {overlay && (
          <div style={{ position: 'absolute', inset: 0, zIndex: 50 }}>
            {renderOverlay()}
          </div>
        )}
      </div>
    </Shell>
  );
}

// ─── Shell (phone frame) ────────────────────────────────────────────
function Shell({ W, H, children, onSwitchToWeb }: { W: number; H: number; children: React.ReactNode; onSwitchToWeb?: () => void }) {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: '#0F172A', padding: '32px 16px' }}>
      <div style={{ width: W, height: H, borderRadius: 48, overflow: 'hidden', boxShadow: '0 32px 80px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.08)', display: 'flex', flexDirection: 'column', position: 'relative', flexShrink: 0 }}>
        {children}
      </div>
      {onSwitchToWeb && (
        <button onClick={onSwitchToWeb} style={{ marginTop: 24, padding: '9px 20px', borderRadius: 24, background: 'rgba(255,255,255,.08)', border: '1px solid rgba(255,255,255,.15)', color: 'rgba(255,255,255,.6)', fontSize: 12, fontFamily: T.body, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/></svg>
          Ver versión web
        </button>
      )}
    </div>
  );
}

// ─── App root ───────────────────────────────────────────────────────
export default function App() {
  const [webMode, setWebMode] = useState(false);
  if (webMode) return <WebApp onSwitchToMobile={() => setWebMode(false)} />;
  return <MobileApp onSwitchToWeb={() => setWebMode(true)} />;
}
